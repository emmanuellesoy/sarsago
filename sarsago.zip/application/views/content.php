<?=(isset($nav)) ? $nav : ''; ?>
<!-- Main Page Content and Sidebar -->

<div class="row">
    <?=(isset($section)) ? $section : ''; ?>
    <?=(isset($toolbar)) ? $toolbar : ''; ?>
</div>
<?=(isset($footer)) ? $footer : ''; ?>