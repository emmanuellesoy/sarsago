<?=doctype('html5'); ?>
<html>
    <head>
        <?=(isset($head)) ? $head : ''; ?>
    </head>
    <body>
        <?=(isset($content)) ? $content : ''; ?>
    </body>
</html>