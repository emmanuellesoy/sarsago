  <!-- Nav Bar -->


  <div class="row">
    <div class="twelve columns">
     
      <div id="banner"></div>

      <ul class="nav-bar">
        <li><a href="<?=base_url(); ?>index.php/principal/index/acceso">ACCESO</a></li>
        <li><a href="<?=base_url(); ?>index.php/principal/index/registrar">REGISTRO</a></li>
        <li><a href="<?=base_url(); ?>index.php/principal/index/imprimir">IMPRESIÓN</a></li>
      </ul>

      <h1><small> Sistema de Acceso y Registro a la 7° Asamblea General Ordinaria</small>
      <hr />
    </div>
  </div>

  <!-- End Nav -->