<!-- Sidebar -->

<aside class="three columns">

    <img src="<?=base_url(); ?>statics/img/camara.png">
    <!--<div class="panel">



        </div>-->

</aside>

<!-- End Sidebar -->