<title>SARSAGO AMIJ</title>
<?=meta('Content-type', 'text/html; charset=utf-8', 'equiv'); ?>
<meta name="viewport" content="width=device-width" />
<link rel="stylesheet" href="<?=base_url(); ?>statics/css/foundation.min.css">
<link rel="stylesheet" href="<?=base_url(); ?>statics/css/app.css">
<link rel="stylesheet" type="text/css" media="all" href="<?=base_url(); ?>statics/css/style.css">
<link rel="stylesheet" type="text/css" media="all" href="<?=base_url(); ?>statics/css/responsive.css">
<link rel="stylesheet" href="<?=base_url(); ?>statics/css/token-input.css">
<link rel="stylesheet" href="<?=base_url(); ?>statics/css/token-input-facebook.css">
<link rel="stylesheet" href="<?=base_url(); ?>statics/css/token-input-mac.css">
<link rel="stylesheet" media="print" href="<?=base_url(); ?>statics/css/print.css">
<script src="<?=base_url(); ?>statics/js/modernizr.foundation.js"></script>