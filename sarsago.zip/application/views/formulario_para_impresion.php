
<div id="gafete">


	<div id="datosQR" style type="text/css" media="print">  
		<label id= "label"><?=$cargo; ?></label>
		<label id= "label"><?=$nombre.' '.$apellidos; ?></label>
		<label id= "label"><?=$oij; ?></label>
	</div>

	<div id ="QR" > 
		<img src="<?=base_url(); ?>statics/img/code_bars/<?=$img_name; ?>.png" height = "100" width ="100" alt="" />
	</div>
</div>

