<footer class="row" id="footer">
    <div class="twelve columns">
      <hr />
      <div class="row">
        <div class="six columns">
          <p>&copy; AMIJ 2012. Todos los derechos reservados</p>
        </div>
        <div class="six columns">
          <ul class="link-list right">
            <img src="<?=base_url(); ?>statics/img/foot.png">
          </ul>
        </div>
      </div>
    </div>
  </footer>
  <script src="<?=base_url(); ?>statics/js/jquery-1.8.2.min"></script>
  <script src="<?=base_url(); ?>statics/js/foundation.min.js"></script>
  <script src="<?=base_url(); ?>statics/js/app.js"></script>
  <script type="text/javascript">var b = "<?=base_url(); ?>";</script>
  <script type="text/javascript" src="<?=base_url(); ?>statics/js/jquery.tokeninput.js"></script>
  <script type="text/javascript" src="<?=base_url(); ?>statics/js/acceso.js"></script>